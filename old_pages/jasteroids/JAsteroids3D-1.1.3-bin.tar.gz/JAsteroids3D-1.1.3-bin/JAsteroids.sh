#!/bin/sh

java -Dspeed=fast -Dusername=djr -Dnasteroids=5 -Dnaststep=4 -Dlgastcolor=FF00FF -Dmedastcolor=00FFFF -Dsmastcolor=FFFF00 -Dshipcolor=FFFFFF -Dsmufocolor=FF9999 -Dlgufocolor=00FF00 -Dtextcolor=55FF55 -Dhsserver=unused -jar jasteroids.jar
