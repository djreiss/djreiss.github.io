#!/bin/tcsh

/bin/nice -16 java -mx128m -cp yajalife.jar:acme-gifencoder.jar -jar yajalife.jar 1

